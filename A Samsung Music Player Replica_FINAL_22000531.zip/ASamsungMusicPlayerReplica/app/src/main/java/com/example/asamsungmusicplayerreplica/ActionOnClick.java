package com.example.asamsungmusicplayerreplica;

public interface ActionOnClick {
    void playBnClicked();
    void skipTrackBnClicked(boolean isNext);
}
